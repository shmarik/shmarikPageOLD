let a = 0
let res =0
function btn(){
    for(let i = 0; i<21; i++){
        if(a=i){

        }
    }
}