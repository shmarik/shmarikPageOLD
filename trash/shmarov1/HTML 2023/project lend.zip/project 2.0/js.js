let a = "это советы новичкам и подбор тренеров в нашем городе"
console.log(a.toUpperCase());