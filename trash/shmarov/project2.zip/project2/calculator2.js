let res = document.querySelector(".gotovo")
console.log(res);